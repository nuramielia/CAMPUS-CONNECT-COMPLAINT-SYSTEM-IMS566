<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Complaint> $complaints
 */
	use Cake\Routing\Router;
	echo $this->Html->css('select2/css/select2.css');
	echo $this->Html->script('select2/js/select2.full.min.js');
	echo $this->Html->css('jquery.datetimepicker.min.css');
	echo $this->Html->script('jquery.datetimepicker.full.js');
	echo $this->Html->script('https://cdn.jsdelivr.net/npm/apexcharts');
	echo $this->Html->script('https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js');
	$c_name = $this->request->getParam('controller');
	echo $this->Html->script('bootstrapModal', ['block' => 'scriptBottom']);
?>
<!--Header-->
<div class="row text-body-secondary">
	<div class="col-10">
		<h1 class="my-0 page_title"><?php echo $title; ?></h1>
		<h6 class="sub_title text-body-secondary"><?php echo $system_name; ?></h6>
	</div>
	

		

			<div class="row">
	<div class="col-md-12">	   
    <div class="row">
        <div class="col-md-12 mx-auto">
            <div class="card shadow-sm">
                <div class="card-header bg-head text-white">
                    <h4 class="mb-0">Complaint Statistics</h4>
                </div>
                <div class="card-body bg-card">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th class="text-center">Category</th>
                                    <th class="text-center">Count</th>
                                    <th class="text-center">Percentage</th>
                                    <th class="text-center">Visual</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Calculate totals
                                $total = $total_facility + $total_electrical + $total_landscape;
                                $categories1 = [
                                    'Facility' => $total_facility,
                                    'Electrical' => $total_electrical,
                                    'Landscape' => $total_landscape
                                ];
                                
                                foreach ($categories1 as $category => $count) {
                                    $percentage = $total > 0 ? round(($count / $total) * 100, 1) : 0;
                                    $barWidth = $percentage;
                                    
                                    echo "<tr>
                                            <td class='align-middle'><strong>$category</strong></td>
                                            <td class='align-middle text-center'>$count</td>
                                            <td class='align-middle text-center'>$percentage%</td>
                                            <td class='align-middle'>
                                                <div class='progress' style='height: 25px;'>
                                                    <div class='progress-bar progress-bar-striped' 
                                                         role='progressbar' 
                                                         style='width: $barWidth%' 
                                                         aria-valuenow='$barWidth' 
                                                         aria-valuemin='0' 
                                                         aria-valuemax='100'>
                                                        $percentage%
                                                    </div>
                                                </div>
                                            </td>
                                          </tr>";
                                }
                                ?>
                                <tr class="table-info">
                                    <td><strong>Total</strong></td>
                                    <td class="text-center"><strong><?php echo $total; ?></strong></td>
                                    <td class="text-center"><strong>100%</strong></td>
                                    <td></td>
                                </tr>
                            </tbody>
                        </table>
                
<br>
<style>
    .progress-bar {
        transition: width 1s ease-in-out;
    }
    .progress-bar:nth-child(1) {
        background-color: #663399;
    }
    .progress-bar:nth-child(2) {
        background-color: #663399;
    }
    .progress-bar:nth-child(3) {
        background-color: #FFCE56;
    }
    .table-hover tbody tr:hover {
        transform: scale(1.01);
        box-shadow: 0 0 10px;
		background-color: #663399;
        transition: all 0.3s ease;
    }
	 .bg-head {
        background-color: #663399;
    }
	.bg-card {
		background-color: #ffffff;
	}.text{
		color: #000000;
	}
</style>
</div>
<br>

<!-- chart -->
			 <!-- Pie chart on the right (col-md-6) -->
    <div class="col-md-6">
        <div class="row">
            <div class="col-md-12 mx-auto">
                <div style="width: 400px; height: 400px;">
                    <div class="bg-card">
  <canvas id="myChart"></canvas>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
  const ctx = document.getElementById('myChart');

  new Chart(ctx, {
    type: 'pie',
    data: {
      labels: ['Facility', 'Electrical', 'Landscape'],
      datasets: [{
        label: '# of Votes',
        data: [<?php echo $total_facility; ?>, <?php echo $total_electrical; ?>, <?php echo $total_landscape; ?>],
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
</script>
<div>
</div>
</div>
</div>


  </div>
        </div>
    </div>
</div>
</div>
</div>
		<div class="tab-pane container fade px-0" id="report">
			<div class="row pb-3">
				<div class="col-md-4">
				  <div class="stat_card card-1 bg-body-tertiary">
					<h3><?php echo $total_complaints; ?></h3>
					<p>Total Complaints</p>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="stat_card card-2 bg-body-tertiary">
					<h3><?php echo $total_complaints_active; ?></h3>
					<p>Active Complaints</p>
				  </div>
				</div>
				<div class="col-md-4">
				  <div class="stat_card card-3 bg-body-tertiary">
					<h3><?php echo $total_complaints_archived; ?></h3>
					<p>Archived Complaints</p>
				  </div>
				</div>
			</div>
			
<div class="row">
	<div class="col-md-6">
	<div class="card bg-body-tertiary border-0 shadow mb-4">
		<div class="card-body">
			<div class="card-title mb-0">Complaints (Monthly)</div>
			<div class="tricolor_line mb-3"></div>
				<div class="chart-container" style="position: relative;">
					<canvas id="monthly"></canvas>
				</div>


<script>
const ctx = document.getElementById('monthly');
const monthly = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($monthArray); ?>,
        datasets: [{
            label: ['Facility', 'Electrical', 'Landscape'],
			data: [<?php echo $total_facility; ?>, <?php echo $total_electrical; ?>, <?php echo $total_landscape; ?>],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        },
		plugins: {
            title: {
                display: false,
                text: 'Complaints (Monthly)',
				font: {
				  size: 15
					}
				},
			subtitle: {
                display: false,
                text: '<?php echo $system_name; ?>'
				},
			legend: {
					display: false,
					labels: {
						color: 'rgb(255, 99, 132)'
					}
				},
        }
    }
});
</script>
		</div>
	</div>
	</div>
	<div class="col-md-6">
	<div class="card bg-body-tertiary border-0 shadow mb-4">
		<div class="card-body">
		<div class="card-title mb-0">Complaints by Status</div>
			<div class="tricolor_line mb-3"></div>
		<div class="chart-container" style="position: relative;">
    <canvas id="status"></canvas>
	<div class="bg-card">
<p>An Overview of Recent Complaint Data
The provided complaint statistics offer a clear snapshot of recent issues, totaling three reported incidents. A significant majority of these complaints, specifically two out of three, fall under the "Facility" category, accounting for 66.7% of all grievances. This indicates that facility-related concerns are the most prevalent area requiring attention. Following "Facility," "Electrical" issues represent the second highest category, with one complaint, making up 33.3% of the total. This suggests that while less frequent than facility problems, electrical concerns still contribute a notable portion to the overall complaint landscape. Interestingly, "Landscape" issues received no complaints during this period, standing at 0%. This could imply either a high level of satisfaction with landscape maintenance or a lack of reporting for this specific category. In summary, the data highlights facility-related problems as the primary area of concern, followed by electrical issues. Addressing these dominant categories would likely lead to a substantial reduction in overall complaints and an improvement in user satisfaction.</p>
</div>
</div>

		</div>
	</div>
	</div>
</div>
		</div>
    </div>
                </div>
            </div>
        </div>
    </div>
</div>
		<div class="tab-pane container fade px-0" id="export">
			<?php
				$domain = Router::url("/", true);
				$sub = 'complaints';
				$combine = $domain . $sub;
			?>
			<div class="row pb-3">
				<div class="col-md-3 mb-2">
				<a href='<?php echo $combine; ?>/csv' class="kosong">
					<div class="card bg-body-tertiary border-0 shadow">
							<div class="card-body">
						<div class="row mx-0">
							<div class="col-5 text-center mt-3 mb-3"><i class="fa-solid fa-file-csv fa-2x text-primary"></i></div>
							<div class="col-7 text-end m-auto">
								<div class="fs-4 fw-bold">CSV</div>
								<div class="small-text"><i class="fa-solid fa-angles-down fa-flip"></i> Download</div>
							</div>
						</div>
					</div>
						</div>
				</a>
				</div>
				<div class="col-md-3 mb-2">
					<a href='<?php echo $combine; ?>/json' class="kosong" target="_blank">
					<div class="card bg-body-tertiary border-0 shadow">
							<div class="card-body">
						<div class="row mx-0">
							<div class="col-5 text-center mt-3 mb-3"><i class="fa-solid fa-braille fa-2x text-warning"></i></div>
							<div class="col-7 text-end m-auto">
								<div class="fs-4 fw-bold">JSON</div>
								<div class="small-text"><i class="fa-solid fa-angles-down fa-flip"></i> Download</div>
							</div>
						</div>
						</div>
					</div>
					</a>
				</div>
				<div class="col-md-3 mb-2">
					<a href='<?php echo $combine; ?>/pdfList' class="kosong">
					<div class="card bg-body-tertiary border-0 shadow">
							<div class="card-body">
						<div class="row mx-0">
							<div class="col-5 text-center mt-3 mb-3"><i class="fa-regular fa-file-pdf fa-2x text-danger"></i></div>
							<div class="col-7 text-end m-auto">
								<div class="fs-4 fw-bold">PDF</div>
								<div class="small-text"><i class="fa-solid fa-angles-down fa-flip"></i> Download</div>
							</div>
						</div>
						</div>
					</div>
					</a>
				</div>
			</div>	
		</div>
</div>
</div>



</div>
	</div>
</div>
</div>

<div class="modal" id="bootstrapModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirm</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
			<i class="fa-regular fa-circle-xmark fa-6x text-danger mb-3"></i>
                <p id="confirmMessage"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="ok">OK</button>
            </div>
        </div>
    </div>
</div>