<!DOCTYPE html>
<html lang="en">
<head>
    <title>Complaints</title>
    <style>
@page {
    margin= 0px !important;
    padding= 0px !important;

}
.uitm-letter {
        font-family: Arial, sans-serif;
        font-size: 10pt;
        line-height: 1.5;
    
        margin-left: 0 auto;
        background-color: #ffffff;
        color: #000000;
    }
    .letter-table {
        border-collapse: collapse;
    }
    .letter-table td {
        padding: 3px 5px;
        vertical-align: top;
    }
    .complaint-details {
        margin: 10px 0;
        padding: 10px;
    }
    .font {
        font-size: 8pt;
    }
    .border {
        border-color: #000000;
    }
    .right {
        text-align: right;
        padding-right: 50px;
    }
   .header-container {
    margin: 0;
    padding: 0;
    width: 100%;
}

.header-image {
    width: 100%;
    display: block;
    margin: 0;
    padding: 0;
}

        </style>
</head>

<body>
    
<div class="header-container">
    <?php echo $this->Html->image('headeruitm.png', [
        'class' => 'header-image',
        'fullBase' => true
    ]); ?>
</div>

    <div class="uitm-letter" width= "320px" align="right">
    <div class="text-center mb-4">
</div>
        <hr style="border-top: 1px solid black; margin: 10px 0;">
      
    
        <p class="text-end font"><strong>Ref: COMP/<?= date('Y') ?>/<?= str_pad($complaint->id, 4, '0', STR_PAD_LEFT) ?></strong></p>
        <p class="text-end">Date: <?= date('d F Y') ?></p>

</div>

UiTM Cawangan Selangor<br/>
Kampus Puncak Perdana<br/>
 Jalan Pulau Indah Au10/A,<br/>
 40150 Shah Alam,<br/>
 Selangor.

<br>
<br>

        
        <p><strong>To Whom It May Concern</strong></p>
        
        <p class="mb-4"><strong>COMPLAINT RECORD</strong></p>
        
        <table class="letter-table" width="100%">
            <tr>
                <td width="30%"><strong>Name</strong></td>
                <td width="70%">: <?= h($complaint->name) ?></td>
            </tr>
            <tr>
                <td><strong>Contact Number</strong></td>
                <td>: <?= h($complaint->phone_number) ?></td>
            </tr>
            <tr>
                <td><strong>Email</strong></td>
                <td>: <?= h($complaint->email) ?></td>
            </tr>
        </table>
        <br>
        <br>
        <p class="mt-3">This is to confirm that the above-named has submitted the following complaint to our office:</p>
        
        <table class="letter-table" width="100%">
           
 
            <tr>
                <td width="30%"><strong>Complaint Title</strong></td>
                <td width="70%">: <?= h($complaint->title) ?></td>
            </tr>
            <tr>
                <td><strong>Category</strong></td>
                <td>: <?= $complaint->has('category') ? h($complaint->category->category) : 'N/A' ?></td>
            </tr>
            <tr>
                <td><strong>Date Reported</strong></td>
                <td>: <?= h($complaint->date->format('d F Y')) ?></td>
            </tr>
            <tr>
                <td><strong>Status</strong></td>
                <td>: <?= $complaint->status == 1 ? 'RESOLVED' : 'PENDING' ?></td>
            </tr>
       
            <tr>
                <td width="30%"><strong>Faculty</strong></td>
                <td width="70%">: <?= $complaint->has('faculty') ? h($complaint->faculty->name) : 'N/A' ?></td>
            </tr>
               
        </table>
<br>
<br>
        <p class="mt-3"><strong>COMPLAINT DETAILS:</strong></p>
        <div class="complaint-details p-2" style="border: 1px solid #ddd; background-color: #f9f9f9;">
            <?= $this->Text->autoParagraph(($complaint->complaint)); ?>
        </div>
        
        <p class="mt-4">Thank you.</p>
        
        <p class="mt-5"><em>*This is computer-generated letter and no signature is required*</em></p>
    <br>
    <br>
<br>
    <br>
</div>
<center>
    <h3>APPENDIX</h3>
 <?php 
            echo $this->Html->image(
                '../files/Complaints/picture/'.$complaint->picture,
                ['width' => '400px', 'class' => 'img-fluid', 'fullBase' => true]
            );
            ?>
            </center>
<br>
<br>
<br>
<?php echo $this->Html->image('bottomuitm.png', ['width'=> '100%', 'class'=>'mt-6', 'fullBase' => true]);?>
<br>
<br>
</div>
</body>

</html>