<?php

/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Complaint $complaint
 * @var \Cake\Collection\CollectionInterface|string[] $categories
 * @var \Cake\Collection\CollectionInterface|string[] $staffs
 * @var \Cake\Collection\CollectionInterface|string[] $faculties
 */
?>
<?php
echo $this->Html->script('ckeditor/ckeditor.js');
?>
<!--Header-->
<div class="row text-body-secondary">
    <div class="col-10">
        <h1 class="my-0 page_title"><?php echo $title; ?></h1>
        <h6 class="sub_title text-body-secondary"><?php echo $system_name; ?></h6>
    </div>
    <div class="col-2 text-end">
        <div class="dropdown mx-3 mt-2">
            <button class="btn p-0 border-0" type="button" id="orederStatistics" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa-solid fa-bars text-primary"></i>
            </button>
            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="orederStatistics">
                <?= $this->Html->link(__('List Complaints'), ['action' => 'index'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?>
            </div>
        </div>
    </div>
</div>
<div class="line mb-4"></div>
<!--/Header-->
<div class="col-lg-12 offset-md-12">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-head text py-3">
                <h3 class="mb-0">
                    Campus Connect Complaint System
                </h3>
             
</div>
</div>
</div>




<div class="card rounded-0 mb-3 bg-body-tertiary border-0 shadow">
    <div class="card-body text-body-secondary">
        <?= $this->Form->create($complaint, ['type' => 'file']) ?>
        <fieldset>
           

<div class="row">
                        <div class="form-group mb-3 col-md-6">
            <?php echo $this->Form->control('category_id', ['options' => $categories, 'class' => 'form-control form-select', 'empty' => 'Select category']); ?>
</div>

<div class="form-group mb-3 col-md-6">
            <?php echo $this->Form->control('staff_id', ['options' => $staffs, 'class' => 'form-control form-select', 'empty' => 'Select staff']); ?>
</div>

<div class="form-group mb-3 col-md-6">
            <?php echo $this->Form->control('faculty_id', ['options' => $faculties, 'class' => 'form-control form-select', 'empty' => 'Select faculty']); ?>
</div>

<div class="form-group mb-3 col-md-6">
            <?php echo $this->Form->control('title'); ?>
</div>

<div class="form-group mb-3 col-md-6">
            <?php echo $this->Form->control('name'); ?>
</div>

<div class="form-group mb-3 col-md-6">
            <?php echo $this->Form->control('phone_number'); ?>
</div>

<div class="form-group mb-3 col-md-6">
            <?php echo $this->Form->control('email'); ?>
</div>

<div class="form-group mb-3 col-md-6">
            <?php echo $this->Form->control('date', ['label' => 'Complaint Date', 'value' => date('Y-m-d'), 'readonly' => true]); ?>

            <style>
                .ck-editor__editable_inline {
                    min-height: 300px;
                }
            </style>
</div>
            </div>

<div class="form-group mb-3 col-md-6">
            <?php echo $this->Form->control('picture', ['type' => 'file']); ?>
</div>

<div class="form-group mb-3 col-md-12">
            <?php echo $this->Form->control('complaint', ['required' => false, 'id' => 'ckeditor', 'label' => 'Complaint']); ?>
            <script>
                ClassicEditor
                    .create(document.querySelector('#ckeditor'))
                    .catch(error => {
                        console.error(error);
                    });
            </script>

        </fieldset>
        <div class="text-end">
            <?= $this->Form->button('Reset', ['type' => 'reset', 'class' => 'btn btn-outline-warning']); ?>
            <?= $this->Form->button(__('Submit'), ['type' => 'submit', 'class' => 'btn btn-outline-primary']) ?>
        </div>
        <?= $this->Form->end() ?>
    </div>
</div>
<style>
  
    .bg-head {
        background-color: #663399;
    }
    </style>