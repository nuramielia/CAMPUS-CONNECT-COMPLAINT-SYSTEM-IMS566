<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Complaint $complaint
 */
?>
<!--Header-->
<div class="row text-body-secondary">
	<div class="col-10">
		<h1 class="my-0 page_title"><?php echo $title; ?></h1>
		<h6 class="sub_title text-body-secondary"><?php echo $system_name; ?></h6>
	</div>
	<div class="col-2 text-end">
		<div class="dropdown mx-3 mt-2">
			<button class="btn p-0 border-0" type="button" id="orederStatistics" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			<i class="fa-solid fa-bars text-primary"></i>
			</button>
				<div class="dropdown-menu dropdown-menu-end" aria-labelledby="orederStatistics">
							<li><?= $this->Html->link(__('Edit Complaint'), ['action' => 'edit', $complaint->id], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
				<li><?= $this->Form->postLink(__('Delete Complaint'), ['action' => 'delete', $complaint->id], ['confirm' => __('Are you sure you want to delete # {0}?', $complaint->id), 'class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
				<li><hr class="dropdown-divider"></li>
				<li><?= $this->Html->link(__('List Complaints'), ['action' => 'index'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
				<li><?= $this->Html->link(__('New Complaint'), ['action' => 'add'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
							</div>
		</div>
    </div>
</div>
<div class="line mb-4"></div>
<!--/Header-->



 <div class="col-lg-3 offset-md-9">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-head text py-3">
                <h6 class="mb-0">
                    Related Picture to The Complaint
                </h6>
</div>
</div>
</div>
<div class="col-md-3 offset-md-9"> <!-- offset-md-9 pushes it to the right -->
    <div class="card bg-body-tertiary border-0 shadow mb-4 float-end"> <!-- float-end for right alignment -->
        <div class="card-body">
            <?php 
            echo $this->Html->image(
                '../files/Complaints/picture/'.$complaint->picture,
                ['width' => '300px', 'class' => 'img-fluid']
            );
            ?>
        </div>
    </div>
</div>
<div class="uitm-letter">
    <div class="text-center mb-4">

        <?php echo $this->Html->image('headeruitm.png', ['width'=> '100%', 'class'=>'mt-6', 'fullBase' => true]);?>
</div>
        <hr style="border-top: 1px solid black; margin: 10px 0;">
        
        <p class="text-end font"><strong>Ref: COMP/<?= date('Y') ?>/<?= str_pad($complaint->id, 4, '0', STR_PAD_LEFT) ?></strong></p>
        <p class="text-end">Date: <?= date('d F Y') ?></p>

  

UiTM Cawangan Selangor<br/>
Kampus Puncak Perdana<br/>
 Jalan Pulau Indah Au10/A,<br/>
 40150 Shah Alam,<br/>
 Selangor.

<br>
<br>

        
        <p><strong>To Whom It May Concern</strong></p>
        
        <p class="mb-4"><strong>COMPLAINT RECORD</strong></p>
        
        <table class="letter-table" width="100%">
            <tr>
                <td width="30%"><strong>Name</strong></td>
                <td width="70%">: <?= h($complaint->name) ?></td>
            </tr>
            <tr>
                <td><strong>Contact Number</strong></td>
                <td>: <?= h($complaint->phone_number) ?></td>
            </tr>
            <tr>
                <td><strong>Email</strong></td>
                <td>: <?= h($complaint->email) ?></td>
            </tr>
        </table>
        <br>
        <br>
        <p class="mt-3">This is to confirm that the above-named has submitted the following complaint to our office:</p>
        
        <table class="letter-table" width="100%">
           
 
            <tr>
                <td width="30%"><strong>Complaint Title</strong></td>
                <td width="70%">: <?= h($complaint->title) ?></td>
            </tr>
            <tr>
                <td><strong>Category</strong></td>
                <td>: <?= $complaint->has('category') ? h($complaint->category->category) : 'N/A' ?></td>
            </tr>
            <tr>
                <td><strong>Date Reported</strong></td>
                <td>: <?= h($complaint->date->format('d F Y')) ?></td>
            </tr>
            <tr>
                <td><strong>Status</strong></td>
              

<td>:
						<?php 
						if($complaint->status == 1){
							echo 'Completed';
						}elseif ($complaint->status == 2){
							echo 'Pending';
						}elseif ($complaint->status == 3)
                    echo 'In Progress';
					?>
					</td>
            <tr>
                <td width="30%"><strong>Faculty</strong></td>
                <td width="70%">: <?= $complaint->has('faculty') ? h($complaint->faculty->name) : 'N/A' ?></td>
            </tr>
               
        </table>
<br>
<br>
        <p class="mt-3"><strong>COMPLAINT DETAILS:</strong></p>
        <div class="complaint-details p-2" style="border: 1px solid #ddd; background-color: #f9f9f9;">
            <?= $this->Text->autoParagraph(($complaint->complaint)); ?>
        </div>
        
        <p class="mt-4">Thank you.</p>
        
        <p class="mt-5"><em>*This is computer-generated letter and no signature is required*</em></p>
    <br>
    <br>
<br>
    <br>


<?php echo $this->Html->image('bottomuitm.png', ['width'=> '100%', 'class'=>'mt-6', 'fullBase' => true]);?>
<br>
<br>



<br>
<br>

<div class="uitm-letter">
    <div class="text-center mb-4">
 <p class="mt-3"><strong>APPENDIX</strong></p>
 <?php 
            echo $this->Html->image(
                '../files/Complaints/picture/'.$complaint->picture,
                ['width' => '400px', 'class' => 'img-fluid']
            );
            ?>
</div>
        </div>
</div>




<br>
<br>
<br>
<?php echo $this->Html->link(
    '<i class="fa-solid fa-file-pdf"></i> Download PDF', 
    ['action' => 'pdf', $complaint->id],
    [
        'class' => 'btn btn-sm btn-dark', 
        'escapeTitle' => false,
        'style' => 'color: white;'
    ]
); ?>


<style>
    .uitm-letter {
        font-family: Arial, sans-serif;
        font-size: 10pt;
        line-height: 1.5;
        max-width: 800px;
        margin: left;
        padding: 20px;
        background-color: #ffffff;
        color: #000000;
    }
    .letter-table {
        border-collapse: collapse;
    }
    .letter-table td {
        padding: 3px 5px;
        vertical-align: top;
    }
    .complaint-details {
        margin: 10px 0;
        padding: 10px;
    }
    .font {
        font-size: 8pt;
    }
    .border {
        border-color: #000000;
    }
    .align {
        margin-right:10px;
    }
    .bg-head {
        background-color: #663399;
    }
    .text {
        color: #ffffff;
    }

</style>