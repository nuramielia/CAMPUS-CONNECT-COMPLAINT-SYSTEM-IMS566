<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Staff $staff
 */
?>
<!--Header-->
<div class="row text-body-secondary">
	<div class="col-10">
		<h1 class="my-0 page_title"><?php echo $title; ?></h1>
		<h6 class="sub_title text-body-secondary"><?php echo $system_name; ?></h6>
	</div>
	<div class="col-2 text-end">
		<div class="dropdown mx-3 mt-2">
			<button class="btn p-0 border-0" type="button" id="orederStatistics" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			<i class="fa-solid fa-bars text-primary"></i>
			</button>
				<div class="dropdown-menu dropdown-menu-end" aria-labelledby="orederStatistics">
							<li><?= $this->Html->link(__('Edit Staff'), ['action' => 'edit', $staff->id], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
				<li><?= $this->Form->postLink(__('Delete Staff'), ['action' => 'delete', $staff->id], ['confirm' => __('Are you sure you want to delete # {0}?', $staff->id), 'class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
				<li><hr class="dropdown-divider"></li>
				<li><?= $this->Html->link(__('List Staffs'), ['action' => 'index'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
				<li><?= $this->Html->link(__('New Staff'), ['action' => 'add'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
							</div>
		</div>
    </div>
</div>
<div class="line mb-4"></div>
<!--/Header-->

<div class="row g-4">
    <div class="col-lg-12">
        <!-- Staff Profile Card -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-head text-white py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h3 class="mb-1">
                            <i class="fas fa-user-tie me-2"></i>
                            <?= h($staff->name) ?>
                        </h3>
                        <span class="text-white-50 small">
                            <i class="fas fa-id-card me-1"></i> Staff ID: <?= $this->Number->format($staff->id) ?>
                        </span>
                    </div>
                    <span class="badge bg-card text-text">
                        <?= h($staff->faculty) ?>
                    </span>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="p-3 mb-3 bg-card rounded">
                            <h5 class="text-muted mb-3"><i class="fas fa-user-circle me-2"></i>Personal Details</h5>
                            <dl class="row mb-0">
                                <dt class="col-sm-5 fw-normal text-muted">Email</dt>
                                <dd class="col-sm-7">
                                    <a href="mailto:<?= h($staff->email) ?>" class="text-decoration-none">
                                        <i class="fas fa-envelope me-1 text-muted"></i>
                                        <?= h($staff->email) ?>
                                    </a>
                                </dd>
                                
                                <dt class="col-sm-5 fw-normal text-muted">Phone</dt>
                                <dd class="col-sm-7">
                                    <a href="tel:<?= h($staff->phone_number) ?>" class="text-decoration-none">
                                        <i class="fas fa-phone me-1 text-muted"></i>
                                        <?= h($staff->phone_number) ?>
                                    </a>
                                </dd>
                            </dl>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="p-3 mb-3 bg-card rounded">
                            <h5 class="text-muted mb-3"><i class="fas fa-info-circle me-2"></i>Account Information</h5>
                            <dl class="row mb-0">
                                <dt class="col-sm-5 fw-normal text-muted">Status</dt>
                                <dd class="col-sm-7">
                                    <span class="badge bg-<?= $staff->status == 1 ? 'success' : 'warning' ?>">
                                        <?= $staff->status == 1 ? 'Active' : 'Inactive' ?>
                                    </span>
                                </dd>
                                
                                <dt class="col-sm-5 fw-normal text-muted">Created</dt>
                                <dd class="col-sm-7">
                                    <i class="far fa-calendar-alt me-1 text-muted"></i>
                                    <?= h($staff->created->format('M j, Y')) ?>
                                </dd>
                                
                                <dt class="col-sm-5 fw-normal text-muted">Last Modified</dt>
                                <dd class="col-sm-7">
                                    <i class="far fa-calendar-alt me-1 text-muted"></i>
                                    <?= h($staff->modified->format('M j, Y')) ?>
                                </dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Related Complaints Card -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-head py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">
                        <i class="fas fa-clipboard-list me-2"></i>
                        Associated Complaints
                    </h4>
                    <span class="badge bg-primary rounded-pill">
                        <?= !empty($staff->complaints) ? count($staff->complaints) : '0' ?>
                    </span>
                </div>
            </div>
            <div class="card-body">
                <?php if (!empty($staff->complaints)) : ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Category</th>
                                    <th>Title</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($staff->complaints as $complaint) : ?>
                                <tr>
                                    <td>#<?= h($complaint->id) ?></td>
                                    <td>
                                        <span class="badge bg-info">
                                            <?= h($complaint->category->category ?? 'N/A') ?>
                                        </span>
                                    </td>
                                    <td>
                                        <strong><?= h($complaint->title) ?></strong>
                                        <div class="text-muted small"><?= (substr($complaint->complaint, 0, 40)) ?></div>
                                    </td>
                                    <td><?= h($complaint->date->format('M j, Y')) ?></td>
                                    <td>
                                        <span class="badge bg-<?= $complaint->status == 1 ? 'success' : 'warning' ?>">
                                            <?= $complaint->status == 1 ? 'Resolved' : 'Pending' ?>
                                        </span>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group btn-group-sm" role="group">
                                            <?= $this->Html->link(
                                                '<i class="fas fa-eye"></i>',
                                                ['controller' => 'Complaints', 'action' => 'view', $complaint->id],
                                                ['class' => 'btn btn-outline-primary', 'escape' => false, 'title' => 'View']
                                            ) ?>
                                            <?= $this->Html->link(
                                                '<i class="fas fa-edit"></i>',
                                                ['controller' => 'Complaints', 'action' => 'edit', $complaint->id],
                                                ['class' => 'btn btn-outline-secondary', 'escape' => false, 'title' => 'Edit']
                                            ) ?>
                                            <?= $this->Form->postLink(
                                                '<i class="fas fa-trash-alt"></i>',
                                                ['controller' => 'Complaints', 'action' => 'delete', $complaint->id],
                                                [
                                                    'class' => 'btn btn-outline-danger',
                                                    'escape' => false,
                                                    'title' => 'Delete',
                                                    'confirm' => __('Are you sure you want to delete complaint # {0}?', $complaint->id)
                                                ]
                                            ) ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                        <h5 class="text-muted">No complaints found</h5>
                        <p class="text-muted small">This staff member currently has no associated complaints.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Sidebar -->
    <div class="col-lg-12">
        <div class="card border-0 shadow-sm mb-4">
           
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    
                </div>
                
        </div>
                
                <div class="alert alert-info small mt-3 mb-0">
                    <i class="fas fa-info-circle me-2"></i>
                    Last login: <?= date('M j, Y \a\t g:i A') ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .card {
        border-radius: 0.5rem;
    }
    .card-header {
        border-bottom: 1px solid rgba(0,0,0,0.05);
    }
    .table-hover tbody tr {
        transition: all 0.2s ease;
    }
    .table-hover tbody tr:hover {
        background-color: rgba(0, 123, 255, 0.05);
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    .badge {
        font-weight: 500;
        padding: 0.35em 0.65em;
    }
    .bg-light {
        background-color: #f8f9fa!important;
    }
    .btn-group-sm .btn {
        padding: 0.25rem 0.5rem;
    }
    .bg-head {
        background-color: #616a6b;
    }
    .bg-card {
        background-color: #424949:
    }
    .text {
color: #000000 ;
    }
</style>