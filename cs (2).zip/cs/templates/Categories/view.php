<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Category $category
 */
?>
<!--Header-->
<div class="row text-body-secondary">
	<div class="col-10">
		<h1 class="my-0 page_title"><?php echo $title; ?></h1>
		<h6 class="sub_title text-body-secondary"><?php echo $system_name; ?></h6>
	</div>
	<div class="col-2 text-end">
		<div class="dropdown mx-3 mt-2">
			<button class="btn p-0 border-0" type="button" id="orederStatistics" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			<i class="fa-solid fa-bars text-primary"></i>
			</button>
				<div class="dropdown-menu dropdown-menu-end" aria-labelledby="orederStatistics">
							<li><?= $this->Html->link(__('Edit Category'), ['action' => 'edit', $category->id], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
				<li><?= $this->Form->postLink(__('Delete Category'), ['action' => 'delete', $category->id], ['confirm' => __('Are you sure you want to delete # {0}?', $category->id), 'class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
				<li><hr class="dropdown-divider"></li>
				<li><?= $this->Html->link(__('List Categories'), ['action' => 'index'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
				<li><?= $this->Html->link(__('New Category'), ['action' => 'add'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
							</div>
		</div>
    </div>
</div>
<div class="line mb-4"></div>
<!--/Header-->


<div class="row g-4">
    <div class="col-lg-12">
        <!-- Main Complaint Card -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-head text-white py-3">
                <h3 class="mb-0">
                    <i class="fas fa-bolt me-2"></i>
                    <?= h($category->category) ?> Complaint Details
                </h3>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="detail-card bg-card p-3 border rounded">
                            <h5 class="text-muted mb-3">Basic Information</h5>
                            <dl class="row mb-0">
                                <dt class="col-sm-4 fw-normal text-muted">Category</dt>
                                <dd class="col-sm-8 fw-bold"><?= h($category->category) ?></dd>
                                
                                <dt class="col-sm-4 fw-normal text-muted">Complaint ID</dt>
                                <dd class="col-sm-8 fw-bold">#<?= $this->Number->format($category->id) ?></dd>
                                
                                <dt class="col-sm-4 fw-normal text-muted">Status</dt>
                                <dd class="col-sm-8">
                                    <span class="badge bg-<?= $category->status == 1 ? 'success' : 'warning' ?>">
                                        <?= $category->status == 1 ? 'Completed' : 'Pending' ?>
                                    </span>
                                </dd>
                            </dl>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="detail-card bg-card p-3 border rounded">
                            <h5 class="text-muted mb-3">Timeline</h5>
                            <dl class="row mb-0">
                                <dt class="col-sm-4 fw-normal text-muted">Created</dt>
                                <dd class="col-sm-8">
                                    <i class="far fa-calendar-alt me-1 text-muted"></i>
                                    <?= h($category->created->format('M j, Y \a\t g:i A')) ?>
                                </dd>
                                
                                <dt class="col-sm-4 fw-normal text-muted">Last Modified</dt>
                                <dd class="col-sm-8">
                                    <i class="far fa-calendar-alt me-1 text-muted"></i>
                                    <?= h($category->modified->format('M j, Y \a\t g:i A')) ?>
                                </dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Related Complaints Card -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-head py-3">
                <h4 class="mb-0">
                    <i class="fas fa-list-ul me-2"></i>
                    Related Complaints
                </h4>
            </div>
            <div class="card-body">
                <?php if (!empty($category->complaints)) : ?>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Submitted By</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($category->complaints as $complaint) : ?>
                                <tr>
                                    <td>#<?= h($complaint->id) ?></td>
                                    <td>
                                        <strong><?= h($complaint->title) ?></strong>
                                        <div class="text-muted small"><?= (substr($complaint->complaint, 0, 50)) ?></div>
                                    </td>
                                    <td>
                                        <?= h($complaint->name) ?>
                                        <div class="text-muted small"><?= h($complaint->email) ?></div>
                                    </td>
                                    <td><?= h($complaint->date->format('M j, Y')) ?></td>
                                    <td>
                                        <span class="badge bg-<?= $complaint->status == 1 ? 'success' : 'warning' ?>">
                                            <?= $complaint->status == 1 ? 'Completed' : 'Pending' ?>
                                        </span>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group btn-group-sm" role="group">
                                            <?= $this->Html->link(
                                                '<i class="fas fa-eye"></i>',
                                                ['controller' => 'Complaints', 'action' => 'view', $complaint->id],
                                                ['class' => 'btn btn-outline-primary', 'escape' => false, 'title' => 'View']
                                            ) ?>
                                            <?= $this->Html->link(
                                                '<i class="fas fa-edit"></i>',
                                                ['controller' => 'Complaints', 'action' => 'edit', $complaint->id],
                                                ['class' => 'btn btn-outline-secondary', 'escape' => false, 'title' => 'Edit']
                                            ) ?>
                                            <?= $this->Form->postLink(
                                                '<i class="fas fa-trash-alt"></i>',
                                                ['controller' => 'Complaints', 'action' => 'delete', $complaint->id],
                                                [
                                                    'class' => 'btn btn-outline-danger',
                                                    'escape' => false,
                                                    'title' => 'Delete',
                                                    'confirm' => __('Are you sure you want to delete # {0}?', $complaint->id)
                                                ]
                                            ) ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No related complaints found</h5>
                        <p class="text-muted small">When related complaints are added, they will appear here.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Sidebar -->
    <div class="col-lg-12">
        <div class="card border-0 shadow-sm mb-4">
            
            <div class="card-body">
                <div class="d-grid gap-2">
                    
                </div>
                
            
                
                
        
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-head py-3">
                <h5 class="mb-0">
                    <i class="fas fa-info-circle me-2"></i>
                    Category Info
                </h5>
            </div>
            <div class="card-body">
                <p class="small text-muted">Electrical complaints typically include issues with wiring, power outages, electrical equipment malfunctions, and other related problems.</p>
                
                <div class="alert alert-warning small mb-0">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <strong>Safety Notice:</strong> Electrical issues should be handled by qualified personnel only.
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .detail-card {
        transition: all 0.2s ease;
        height: 100%;
    }
    .detail-card:hover {
        box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        transform: translateY(-2px);
    }
    .card-header {
        border-bottom: none;
    }
    table.table-hover tbody tr {
        cursor: pointer;
        transition: background-color 0.15s ease;
    }
    table.table-hover tbody tr:hover {
        background-color: rgba(0, 123, 255, 0.05);
    }
    .bg-card {
        background-color: #512e5f;
    }
    .bg-head {
        background-color: #8e44ad;
    }
</style>



