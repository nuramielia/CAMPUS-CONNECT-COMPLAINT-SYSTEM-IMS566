<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Complaint Entity
 *
 * @property int $id
 * @property int $category_id
 * @property int $staff_id
 * @property int $faculty_id
 * @property int $title
 * @property string $name
 * @property string $phone_number
 * @property string $email
 * @property \Cake\I18n\Date $date
 * @property string $picture
 * @property string $picture_dir
 * @property string $complaint
 * @property int $status
 * @property \Cake\I18n\DateTime $created
 * @property \Cake\I18n\DateTime $modified
 *
 * @property \App\Model\Entity\Category $category
 * @property \App\Model\Entity\Staff $staff
 * @property \App\Model\Entity\Faculty $faculty
 */
class Complaint extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'category_id' => true,
        'staff_id' => true,
        'faculty_id' => true,
        'title' => true,
        'name' => true,
        'phone_number' => true,
        'email' => true,
        'date' => true,
        'picture' => true,
        'picture_dir' => true,
        'complaint' => true,
        'status' => true,
        'created' => true,
        'modified' => true,
        'category' => true,
        'staff' => true,
        'faculty' => true,
    ];
}
